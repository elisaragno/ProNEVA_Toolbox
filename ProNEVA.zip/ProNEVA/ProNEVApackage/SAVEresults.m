% -------------------------------------------------------------------------
% SAVE RESULTS
% -------------------------------------------------------------------------

function SAVEresults(OBS, RUNspec, OUT, DGN, currentDIR)

%currentDIR = pwd;
cd(currentDIR)

if exist('Results','file')
    % Create additional Results dir to avoid overwriting previous runs
    
    listResultsDirs = dir('Results*'); % pull all dir with Results in name
    [ndirs, nlist] = size(listResultsDirs); % get count of dir

    if ispc
        dirName = strcat(currentDIR, '\Results_', num2str(ndirs+1)); % PC
    else
        dirName = strcat(currentDIR, '/Results_', num2str(ndirs+1)); % MAC
    end 
else
    % Create first Results dir 
    if ispc
        dirName = strcat(currentDIR, '\Results'); % PC
    else
        dirName = strcat(currentDIR, '/Results'); % MAC
    end 
end

mkdir(dirName);
cd(dirName)

switch RUNspec.DISTR.Model
    
    case 'Stat'
        % Create a StationaryAnalysis folder if it does not exist
        if exist('StationaryAnalysis','file') == 0    
            if ispc
                mkdir([pwd,'\StationaryAnalysis']); % for PC
            else
                mkdir([pwd,'/StationaryAnalysis']); % for MAC
            end      
        end
        % Open folder
        cd StationaryAnalysis
        % Save Workspace 
        save( 'StatAnalysisResults.mat', 'OBS', 'RUNspec', 'OUT', 'DGN');
        % Save Figures
        ListFigure = findobj('type', 'Figure');
        savefig(ListFigure, 'Figures.fig');
        
    case 'NonStat'
        % Create a NonStationaryAnalysis folder if it does not exist
        if exist('NonStationaryAnalysis','file') == 0
            if ispc
                mkdir([pwd,'\NonStationaryAnalysis']); % for PC
            else
                mkdir([pwd,'/NonStationaryAnalysis']); % for MAC
            end  
        end
        % Open Folder
        cd NonStationaryAnalysis
        % Save Workspace
        save( 'NonStatAnalysisResults.mat', 'OBS', 'RUNspec', 'OUT', 'DGN');
        % Save Figures
        ListFigure = findobj('type', 'Figure');
        savefig(ListFigure, 'Figures.fig');

end
% BACK TO ORIGINAL DIRECTORY
cd(currentDIR)