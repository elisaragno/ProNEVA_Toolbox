%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Script for extracting 1- to 7-day duration annual maxima and calculating
% the return levels for the different storm durations. It plots return 
% level curves for each duration and the Intensity-Duration-Frequency (IDF) 
% curve for the 50-year return period.
%
%  Input: 
%   - Tab delimited text file with 4 columns:
%       col 1) year
%       col 2) month
%       col 3) day
%       col 4) observations (e.g., precipitation, temperature)
%
%  Output:
%   - A plot with return levels for each storm duration
%   - An Intensity-Duration-Frequency (IDF) curve for 50-year return period
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; % clear workspace


%% Read the data
file_name = 'Precip_New_Orleans_CMIP5.txt';

% preview file content and confirm correct format
opts = detectImportOptions(file_name);
preview(file_name, opts) 

% Read the data, ignoring the header row
file_obs = fopen(file_name);      
text_obs  = textscan(file_obs, '%f %f %f %f', 'HeaderLines', 1);
fclose(file_obs);

% Save each column in a different vector
yr = text_obs{1}(:);
mon = text_obs{2}(:);
day = text_obs{3}(:);
obs = text_obs{4}(:);

% Extract the number of years
allyrs = unique(yr);
nYr = length(allyrs);


%% Annual Maxima for 1- to 7-day events
D = 1:7; % durations
for i = 1:nYr
    
    oneYr = obs(yr == allyrs(i)); % one year of data
    
    % Increment through each year for the different durations to 
    % create 1- to 7-day annual maxima time series
    for t = 1:length(D)        
        for j = 1:length(oneYr) - (D(t)-1)
           
            obsD(j) = sum( oneYr(j:j+D(t)-1) )/D(t);
            
        end    
        obsMaxD(i,t) = max(obsD);        
        clear obsD
    end
    
    clear oneYr
end

%% Fit stationary GEV to the different durations of AM 

% 2- to 100-yr return periods (RP)
RP = 2:100;

% Exceedance probabilities associated with each RP
p = 1 - 1./RP; 

% Calculate return levels for the different storm durations
for d = 1:length(D)
    
    GEVparam = gevfit(obsMaxD(:,d));
    GEVshape = GEVparam(1);
    GEVscale = GEVparam(2);
    GEVlocation = GEVparam(3);
    
    % Calculate return levels for each return period
    for i = 1:length(RP)
        RLgevD(i,d) = gevinv(p(i), GEVshape, GEVscale, GEVlocation);
    end
end

%% Plot return level curves for each duration
figure;
hold on

for t = 1:length(D)
    plot(RP', RLgevD(:, t));
end

xlabel("Return Period");
ylabel("Return Level [in]");
title("1- to 7-Day Duration Annual Maxima Return Levels");
legend("1-Day", "2-Day", "3-Day", "4-Day", "5-Day", "6-Day", "7-Day", 'Location','northwest');
hold off


%% Plot Intensity-Duration-Frequency (IDF) curve for 50-year return period

IDF50 = RLgevD(49 , :);

figure;
plot( 1:7, IDF50 );
xlabel('Duration [day]');
ylabel('Intensity [inch/day]');
title("IDF Curve, 50-year Return Period");
