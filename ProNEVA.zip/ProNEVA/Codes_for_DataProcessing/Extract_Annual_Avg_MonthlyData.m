%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Script for creating annual (Jan-Dec) average time series.
%  Input: 
%   - Tab delimited text file with 4 columns:
%       col 1) year
%       col 2) month
%       col 3) observation (e.g., CO2 concentration)
%  Output:
%   - A single text file containing 
%       -- one column vector of observed annual averages
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; % clear workspace

%% Read the data
file_name = 'Monthly_CO2_ScrippsPier.txt'; % EDIT as needed

% read data in as a table to check summary of content
opts = detectImportOptions( file_name ); % import options based on file content
filedata = readtable( file_name, opts ); % read file as a table
summary( filedata ) % check min/max date range

% Separate out columns into arrays (convert from table format)
yr  = table2array( filedata( :, 1 ) );
mon = table2array( filedata( :, 2 ) );
obs = table2array( filedata( :, 3 ) );

% % If reading your data in as a table isn't working with your version of
% % Matlab, uncomment and use basic textscan to read the data, ignoring the 
% % header row.
% file_obs = fopen( file_name );      
% filedata  = textscan( file_obs, '%f %f %f', 'HeaderLines', 1 );
% fclose( file_obs );
%
% % Separate out columns into arrays (convert from cell array format)
% yr  = filedata{ 1, 1 }(:);
% mon = filedata{ 1, 2 }(:);
% obs = filedata{ 1, 3 }(:);

%% Extract the number of years
allyrs = unique( yr );
nYr = length( allyrs );


%%  Create a time series of annual average values
% loop through each year, calculate and save maximum value
AA_obs = zeros( nYr, 1 );     
for i = 1:nYr 
    temp = obs( yr == allyrs(i) ); % all obs that fall within a single year
    AA_obs( i, 1 ) = mean( temp ); 
    clear temp
end


%% Define start/end years to confirm the covariate data matches time period of obs
start_yr = 1962; % EDIT as needed
end_yr = 2017; % EDIT as needed

%% Subset time series to match specified year range
startIDX = find( allyrs == start_yr ); % start index
endIDX   = find( allyrs == end_yr ); % end index
AA_subset = AA_obs( startIDX:endIDX );


%% Write time series to text file
% add date range to output file name
fileOut_Name = strcat( 'CO2_Annual_Average_Time_Series_', ...
                      num2str( start_yr ), '-', num2str( end_yr ), '.txt' );

% print data to text file
fileOut = fopen( fileOut_Name, 'w' );
fprintf( fileOut, '%f\n', AA_subset );
fclose( fileOut );
    


