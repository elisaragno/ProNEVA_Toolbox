%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Script for fitting a stationary GEV distribution to a single 
% annual maxima time series and calculating return levels for 2- to
% 100-year return periods. Produces a return level plot with 95% CI.
%
%  Input: 
%   - Single text file with 1 columns of observed annual maxima
%
%  Output:
%   - A return level plot with 95% CI
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; % clear workspace

%% Read the data
file_name = 'PRECIP_AM_Time_Series.txt';

% Read the data, ignoring the header row
file_obs = fopen(file_name);      
text_obs  = textscan(file_obs, '%f');
fclose(file_obs);

AM_obs = text_obs{1}; % change data format from cell array to double


%% Fit stationary GEV to 24-hr AM and calculate corresponding return levels

% 2- to 100-yr return periods (RP)
RP = 2:100;

% Exceedance probabilities associated with each RP
p = 1 - 1./RP; 

% GEV fit of AM, and 95% CI
[GEV_param, GEV_paramCI] = gevfit(AM_obs); 

% Separate out GEV parameters to make code easier to read
GEVshape = GEV_param(1);
GEVscale = GEV_param(2);
GEVlocation = GEV_param(3);

% Separate out lower and uppper uncertainty bounds
GEVshape_lower = GEV_paramCI(1,1);
GEVshape_upper = GEV_paramCI(2,1);
GEVscale_lower = GEV_paramCI(1,2);
GEVscale_upper = GEV_paramCI(2,2);
GEVloc_lower = GEV_paramCI(1,3);
GEVloc_upper = GEV_paramCI(2,3);

% Calculate return levels (RLs)
GEV_RLs = gevinv( p, GEVshape, GEVscale, GEVlocation ); % return levels
    
% Calculate RL uncertainty bounds
CI_lower = gevinv( p, GEVshape_lower, GEVscale_lower, GEVloc_lower);
CI_upper = gevinv( p, GEVshape_upper, GEVscale_upper, GEVloc_upper);

%% Plot GEV 25-hour AM return levels

figure; % open new figure
hold on % so we can add both the CI and RL

% plot RL as line
plot(RP, GEV_RLs, 'b', 'linewidth', 2); % plot RL line in blue

% plot CI as dashed lines
y = [CI_lower, CI_upper];  % upper & lower boundaries for fill
plot(RP, CI_lower, '--b', 'linewidth', 1)
plot(RP, CI_upper, '--b', 'linewidth', 1)

% figure labels
xlabel("Return Period");
ylabel("Return Level [in]");
title("Annual Maxima, GEV");
hold off

  