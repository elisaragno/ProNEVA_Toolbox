%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Script for creating annual (Jan-Dec) maxima time series.
%  Input: 
%   - Tab delimited text file with 4 columns:
%       col 1) year
%       col 2) month
%       col 3) day
%       col 4) observation (e.g., precipitation, temperature)
%  Output:
%   - A single text file containing 
%       -- one column vector of observed annual maxima
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; % clear workspace

%% Read the data
file_name = 'Precip_New_Orleans_CMIP5.txt';

% preview file content and confirm correct format
opts = detectImportOptions(file_name);
preview(file_name, opts) 

% Read the data, ignoring the header row
file_obs = fopen(file_name);      
text_obs  = textscan(file_obs, '%f %f %f %f', 'HeaderLines', 1);
fclose(file_obs);

% Save each column in a different vector
yr = text_obs{1,1}(:);
mon = text_obs{1,2}(:);
day = text_obs{1,3}(:);
obs = text_obs{1,4}(:);

% Extract the number of years
allyrs = unique(yr);
nYr = length(allyrs);


%%  Create a time series of annual maxima (AM) values
% loop through each year, calculate and save maximum value
AM_obs = zeros(nYr, 1);     
for i = 1:nYr 
    temp = obs(yr == allyrs(i)); % all obs that fall within a single year
    AM_obs(i,1) = max(temp); 
    clear temp
end

%% Write AM time series to text file
fileOut_Name = 'PRECIP_AM_Time_Series.txt';

fileOut = fopen(fileOut_Name,'w');
fprintf(fileOut,'%f\n', AM_obs);
fclose(fileOut);
    


