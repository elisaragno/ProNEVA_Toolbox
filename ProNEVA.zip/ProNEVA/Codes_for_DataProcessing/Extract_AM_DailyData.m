%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Script for creating annual (Jan-Dec) maxima time series.
%  Input: 
%   - Tab delimited text file with 4 columns:
%       col 1) year
%       col 2) month
%       col 3) day
%       col 4) observation (e.g., precipitation, temperature)
%  Output:
%   - A single text file containing 
%       -- one column vector of observed annual maxima
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; % clear workspace

%% Read the data
file_name = 'Daily_Temperature_ScrippsPier_LaJolla.txt'; % EDIT as needed

% read data in as a table to check summary of content
opts = detectImportOptions( file_name ); % import options based on file content
filedata = readtable( file_name, opts ); % read file as a table
summary( filedata ) % check min/max date range

% Separate out columns into arrays (convert from table format)
yr  = table2array( filedata( :, 1 ) );
mon = table2array( filedata( :, 2 ) );
day = table2array( filedata( :, 3 ) );
obs = table2array( filedata( :, 4 ) );

% % If reading your data in as a table isn't working with your version of
% % Matlab, uncomment and use basic textscan to read the data, ignoring the 
% % header row.
% file_obs = fopen( file_name );      
% text_obs  = textscan( file_obs, '%f %f %f', 'HeaderLines', 1 );
% fclose( file_obs );
% 
% % Separate out columns into arrays (convert from cell array format)
% yr  = filedata{ 1, 1 }(:);
% mon = filedata{ 1, 2 }(:);
% day = filedata{ 1, 3 }(:);
% obs = filedata{ 1, 4 }(:);

%% Extract unique years from data
allyrs = unique( yr ); % all uniques years
nYr = length( allyrs ); % number of years 


%%  Create a time series of annual maxima (AM) values
% loop through each year, calculate and save maximum value
AM_obs = zeros( nYr, 1 );     
for i = 1:nYr 
    temp = obs( yr == allyrs(i) ); % all obs that fall within a single year
    AM_obs( i, 1 ) = max( temp ); 
    clear temp
end


%% Define start/end years so the data matches with time period of covariates
start_yr = 1962; % EDIT as needed
end_yr = 2017; % EDIT as needed


%% Subset time series to match specified year range
startIDX = find( allyrs == start_yr ); % start index
endIDX = find( allyrs == end_yr ); % end index
AM_subset = AM_obs( startIDX:endIDX );


%% Write time series to text file
% add date range to output file name
fileOut_Name = strcat( 'TEMP_AM_Time_Series_', num2str (start_yr ), '-', ...
                      num2str( end_yr ), '.txt' );

% print data to text file
fileOut = fopen( fileOut_Name, 'w' );
fprintf( fileOut,'%f\n', AM_subset );
fclose( fileOut );
    


